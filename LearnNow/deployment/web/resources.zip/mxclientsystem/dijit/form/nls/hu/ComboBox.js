//>>built
define("dijit/form/nls/hu/ComboBox",({previousMessage:"Előző menüpontok",nextMessage:"További menüpontok"}));
