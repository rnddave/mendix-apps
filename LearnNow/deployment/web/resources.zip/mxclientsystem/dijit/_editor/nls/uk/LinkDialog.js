//>>built
define("dijit/_editor/nls/uk/LinkDialog",({createLinkTitle:"Властивості посилання",insertImageTitle:"Властивості зображення",url:"URL:",text:"Опис:",target:"Призначення:",set:"Встановити",currentWindow:"Поточне вікно",parentWindow:"Батьківське вікно",topWindow:"Найвище вікно",newWindow:"Нове вікно"}));
