//>>built
define("dijit/_editor/nls/bs/FontChoice",{fontSize:"Veličina",fontName:"Font",formatBlock:"Format",serif:"serif","sans-serif":"bez-serifa",monospace:"monoprostor",cursive:"kurziv",fantasy:"Fantazija",noFormat:"ništa",p:"Paragraf",h1:"Naslov",h2:"Podnaslov",h3:"Pod-podnaslov",pre:"Predformatizovano",1:"xx-malo",2:"x-malo",3:"maleno",4:"srednje",5:"veliko",6:"x-veliko",7:"xx-veliko"});
