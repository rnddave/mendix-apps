//>>built
define("dijit/nls/kk/common",({buttonOk:"OK",buttonCancel:"Болдырмау",buttonSave:"Сақтау",itemClose:"Жабу"}));
